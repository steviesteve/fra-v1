<?php
// $Id: panels-dashboard-link.tpl.php,v 1.3 2010/10/11 22:56:02 sdboyer Exp $
?>
<div class="dashboard-entry clearfix">
  <div class="dashboard-text">
    <div class="dashboard-link">
      <?php print $link['title']; ?>
    </div>
    <div class="description">
      <?php print $link['description']; ?>
    </div>
  </div>
</div>
